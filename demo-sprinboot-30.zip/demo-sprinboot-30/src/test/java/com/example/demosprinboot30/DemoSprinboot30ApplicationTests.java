package com.example.demosprinboot30;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoSprinboot30ApplicationTests {

    @Test
    void contextLoads() {
    }

}
