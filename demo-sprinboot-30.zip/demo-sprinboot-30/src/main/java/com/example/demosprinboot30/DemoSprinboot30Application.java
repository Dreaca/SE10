package com.example.demosprinboot30;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoSprinboot30Application {

    public static void main(String[] args) {

        SpringApplication.run(DemoSprinboot30Application.class, args);
    }

}
